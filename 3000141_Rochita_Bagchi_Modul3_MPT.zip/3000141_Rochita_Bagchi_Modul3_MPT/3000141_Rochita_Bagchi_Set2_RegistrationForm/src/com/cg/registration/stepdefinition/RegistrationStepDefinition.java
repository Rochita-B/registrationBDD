package com.cg.registration.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.registration.pagebeans.RegistrationBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	private WebDriver driver;  //setting up the webdriver class

	private RegistrationBean pageBean;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", 
				"D:\\141_Rochita_Bagchi\\chromedriver_win32\\chromedriver.exe");    //setting up the webdriver class
		driver=new ChromeDriver();
	}


	@Given("^User is accessing the RegistrationPage on browser$")
	public void user_is_accessing_the_RegistrationPage_on_browser() throws Throwable {
		driver.get("D:\\Users\\ADM-IG-HWDLAB1D\\Desktop\\WebPages\\RegistrationForm.html");   //to get the registration form 
		pageBean=PageFactory.initElements(driver, RegistrationBean.class);
	}

	@When("^user is trying to submit data without entering 'userId'$")
	public void user_is_trying_to_submit_data_without_entering_userId() throws Throwable {
		pageBean.clickSignUp();																																//validation for userID
	}

	@Then("^'UserId should not be empty/length between (\\d+) to (\\d+)' alert message should be displayed$")
	public void userid_should_not_be_empty_length_between_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
		String expectedAlertMessage ="User Id should not be empty / length be between 5 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}


	
	@When("^user is trying to submit request without entering 'password'$")															//validation for password
	public void user_is_trying_to_submit_request_without_entering_password() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("rochita123");
		pageBean.clickSignUp();		
	}

	@Then("^'Password should not be empty/length between (\\d+) to (\\d+)' alert message should be displayed$")
	public void password_should_not_be_empty_length_between_to_alert_message_should_be_displayed(int arg1, int arg2) throws Throwable {
		String expectedAlertMessage ="Password should not be empty / length be between 7 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}
	@When("^user is trying to submit request without entering 'name'$")							//validation for username
	public void user_is_trying_to_submit_request_without_entering_name() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setPassword("tubul123");
		pageBean.clickSignUp();
	}

	@Then("^'Name should not be empty and must have alphabet characters only' alert message should be displayed$")
	public void name_should_not_be_empty_and_must_have_alphabet_characters_only_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage ="Name should not be empty and must have alphabet characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}
	@When("^user is trying to submit request without entering 'address'$")																//validation for address
	public void user_is_trying_to_submit_request_without_entering_address() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setName("rochitabagchi");
		pageBean.setAddress("Kolkata");
		pageBean.clickSignUp();
	}

	@Then("^'User address must have alphanumeric characters only' alert message should be displayed$")
	public void user_address_must_have_alphanumeric_characters_only_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage ="Select your country from the list";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^user is trying to submit request without entering 'country'$")						//validation for country
	public void user_is_trying_to_submit_request_without_entering_country() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setAddress("Kolkata1234");
		pageBean.setCountry("(Please select a country)");
		pageBean.clickSignUp();
	}

	@Then("^'select your country from the list' alert message should be displayed$")
	public void select_your_country_from_the_list_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage="Select your country from the list";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);

	}

	@When("^user is trying to submit request without entering 'zipCode'$")									//validation for zipcode
	public void user_is_trying_to_submit_request_without_entering_zipCode() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setCountry("India");
		pageBean.setZip("abcdef");
		pageBean.clickSignUp();
	}

	@Then("^'ZIP code must have numeric characters only' alert message should be displayed$")
	public void zip_code_must_have_numeric_characters_only_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage="ZIP code must have numeric characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^user is trying to submit request without entering valid 'emailId'$")							//validation for emailId
	public void user_is_trying_to_submit_request_without_entering_valid_emailId() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setZip("700006");
		pageBean.setEmail("rochita.bagchi#gmail.com");
		pageBean.clickSignUp();
	}

	@Then("^'You have entered an invalid email address!' alert message should be displayed$")
	public void you_have_entered_an_invalid_email_address_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage="You have entered an invalid email address!";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^user is trying to submit request without entering the 'sex'$")											//validation for gender
	public void user_is_trying_to_submit_request_without_entering_the_sex() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setEmail("rochita.bagchi@gmail.com");
		pageBean.clickSignUp();
	}

	@Then("^'Please select gender' alert message should be displayed$")
	public void please_select_gender_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage="Please Select gender";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request after entering valid set of information$")												//to test for valid set of details
	public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
		pageBean.setUserId("rochita123");
		pageBean.setName("rochitabagchi");
		pageBean.setPassword("tubul123");
		pageBean.setAddress("Kolkata1234");
		pageBean.setCountry("India");
		pageBean.setZip("700006");
		pageBean.setEmail("rochita.bagchi@gmail.com");
		pageBean.setSex("Female");
		pageBean.clickSignUp();
	}

	@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile' alert message should be displayed$")
	public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile_alert_message_should_be_displayed() throws Throwable {
		String expectedAlertMessage="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@After
	public void tearDownStepEnv() {
		driver.switchTo().alert().dismiss();
		driver.close();
	}

}
